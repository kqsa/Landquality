#' insert mean-value to SpatialPolygonsDataFrame meanwhile assess the heaval metals and benefical elements
#' @docType package
#' @name AssessmentLandquality
#' @aliases Assessment_Landquality
NULL
