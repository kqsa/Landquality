#' @title indicators of soil
#' @description a spatial dataframe contains some heaval metals ,beneficial elements and pH
#' which contains with CRS's lon and lat
#' @docType data
#' @name spatial_data
#' @format a data.frame
#' \describe{
#'   \item{number}{ID of the soil sample}
#'   \item{lon}{the longitude of WGS84 system}
#'   \item{lat}{the latitude of WGS84 system}
#'   \item{As}{a indicators of soil smaple ,such as Hg,P,K,pH}
#'   \item{land}{the soil sample coming from the states of land-used}
#'   }
#' @source the data coming from sichuan geological survey,in China
#' @author Kequan-Xu <xukqsa@@163.com>
NULL
