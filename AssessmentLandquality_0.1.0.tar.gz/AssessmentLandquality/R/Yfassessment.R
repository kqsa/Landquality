#' @title  assessment of beneficial elements of soil
#' @description
#' \code {Yfassessment} assess the benefical elements of the data coming from the SpatialDataframe-returned from TBchazhi or self-dataframe
#' @param yffc one dataframe or SpatialDataframe-returned from TBchazhi
#' @param yfele contains beneficial elements ,such as P,N,K,Se,I,F

#' @param explain a logical value.for example \code{TRUE},explain the Yf_assessment function's methods of use stoping the function
#' \code{FALSE},running the function
#' @export
#' @return a dataframe or SpatialDataframe is the same with the the class of the fcdata
#' @author Kequan-Xu <xukqsa@@163.com>
#' @examples
#' library(sp)
#' library(gstat)
#' library(stringr)
#' data("spatial_data")
#' data("SpatialPolygonsDataFrame")
#' coordinates(data) <- c("lon", "lat")
#' proj4string(data) <- CRS("+proj=longlat +datum=WGS84")
#' data <- spTransform(data, CRS("+proj=tmerc +lat_0=0 +lon_0=105 +k=1 +x_0=35500000 +y_0=0 +ellps=GRS80 +units=m +no_defs"))
#' ele <- c("P", "K", "pH", "As", "Hg")
#' m <- TBchazhi(ele, data, tb)
#' benefical_ele <- c("P", "K")
#' Yf_m <- Yfassessment(m, benefical_ele, explain = \code{FALSE})
Yfassessment <- function(yffc, yfele = c("N", "P", "K", "Se", "I", "F"), explain = T) {
  if (explain == T) {
    return(print("(1)导入数据是否为对数数据，如是对数数据，请将数据转换为普通数据后导入。\n
                 (2)导入数据坐标的名字是否为x和y，如不是需要修改坐标名。\n
                 (3)确保N、P、K都存在，且单位都为%\n
                 （4）包含了Se，I，F评价\n
                 (5)所有改好确定后，将explain设置为FAUSE
              "))
  }
  yffc_name <- names(yffc)
  PD <- length(grep('_pred',yffc_name))#判断导入的数据框是否有_pred
  if(PD>0){
    name_ele <- str_remove_all(paste(yfele, "_pred"), " ")

    name_ele <- names(yffc)[names(yffc) %in% name_ele] # 过滤掉数据框中没有的指标
    print('导入数据可能源自TBchazhi函数，含_pred标志')

  }else{
    name_ele <- names(yffc)[names(yffc) %in% yfele] # 过滤掉数据框中没有的指标
    print('导入数据不源自TBchaizhi函数，不含_pred标志')
  }

  yfdata <- as.data.frame(yffc)[, name_ele]

  # 将N、P、K单位由%统一到g/kg
  if(PD>0){
    NPK <- c("N_pred", "P_pred", "K_pred")
  }else{
    NPK <- c('N','P','K')
  }
  dw_name_ele <- name_ele[name_ele %in% NPK] # 过滤掉数据框中没有的指标

  for (i in dw_name_ele) {
      yfdata[,i] <- yfdata[,i]*10

  }



  for (i in name_ele) {
    if (i == "N_pred"||i == "N") {
      yfdata$N_pj <- NA
      yfdata[which(yfdata[, i] > 2), "N_pj"] <- 1
      yfdata[which(yfdata[, i] > 1.5 & yfdata[, i] <= 2), "N_pj"] <- 2
      yfdata[which(yfdata[, i] > 1 & yfdata[, i] <= 1.5), "N_pj"] <- 3
      yfdata[which(yfdata[, i] > 0.75 & yfdata[, i] <= 1), "N_pj"] <- 4
      yfdata[which(yfdata[, i] <= 0.77), "N_pj"] <- 5
    } else if (i == "P_pred"||i == "P") {
      yfdata$P_pj <- NA
      yfdata[which(yfdata[, i] > 1), "P_pj"] <- 1
      yfdata[which(yfdata[, i] > 0.8 & yfdata[, i] <= 1), "P_pj"] <- 2
      yfdata[which(yfdata[, i] > 0.6 & yfdata[, i] <= 0.8), "P_pj"] <- 3
      yfdata[which(yfdata[, i] > 0.4 & yfdata[, i] <= 0.6), "P_pj"] <- 4
      yfdata[which(yfdata[, i] <= 0.4), "P_pj"] <- 5
    } else if (i == "K_pred"||i == "K") {
      yfdata$K_pj <- NA
      yfdata[which(yfdata[, i] > 25), "K_pj"] <- 1
      yfdata[which(yfdata[, i] > 20 & yfdata[, i] <= 25), "K_pj"] <- 2
      yfdata[which(yfdata[, i] > 15 & yfdata[, i] <= 20), "K_pj"] <- 3
      yfdata[which(yfdata[, i] > 10 & yfdata[, i] <= 15), "K_pj"] <- 4
      yfdata[which(yfdata[, i] <= 10), "K_pj"] <- 5
    } else if (i == "Se_pred"||i == "Se") {
      yfdata$Se_pj <- NA
      yfdata[which(yfdata[, i] > 3), "Se_pj"] <- "Surplus"
      yfdata[which(yfdata[, i] > 0.4 & yfdata[, i] <= 3), "Se_pj"] <- "High"
      yfdata[which(yfdata[, i] > 0.175 & yfdata[, i] <= 0.4), "Se_pj"] <- "Appropriate amount"
      yfdata[which(yfdata[, i] > 0.125 & yfdata[, i] <= 0.175), "Se_pj"] <- "Edge"
      yfdata[which(yfdata[, i] <= 0.125), "Se_pj"] <- "Lack"
      yfdata$Se_pj <- as.factor(yfdata$Se_pj)
    } else if (i == "I_pred"||i == "I") {
      yfdata$I_pj <- NA
      yfdata[which(yfdata[, i] > 100), "I_pj"] <- "Surplus"
      yfdata[which(yfdata[, i] > 5 & yfdata[, i] <= 100), "I_pj"] <- "High"
      yfdata[which(yfdata[, i] > 1.5 & yfdata[, i] <= 5), "I_pj"] <- "Appropriate amount"
      yfdata[which(yfdata[, i] > 1 & yfdata[, i] <= 1.5), "I_pj"] <- "Edge"
      yfdata[which(yfdata[, i] <= 1), "I_pj"] <- "Lack"
      yfdata$I_pj <- as.factor(yfdata$I_pj)
    } else if (i == "F_pred"||i == "F") {
      yfdata$F_pj <- NA
      yfdata[which(yfdata[, i] > 700), "F_pj"] <- "Surplus"
      yfdata[which(yfdata[, i] > 550 & yfdata[, i] <= 700), "F_pj"] <- "High"
      yfdata[which(yfdata[, i] > 500 & yfdata[, i] <= 550), "F_pj"] <- "Appropriate amount"
      yfdata[which(yfdata[, i] > 400 & yfdata[, i] <= 500), "F_pj"] <- "Edge"
      yfdata[which(yfdata[, i] <= 400), "F_pj"] <- "Lack"
      yfdata$F_pj <- as.factor(yfdata$F_pj)
    }
  }
  if (length(dw_name_ele) == 3) {
    ### 第一次将1替换为6，新建得分列，第二次评价开始直到最后，需要在新建列上进行替换并赋给自己，保证原有被替换的数据，被重新覆盖。
    yfdata <- transform(yfdata,
      Ndf = as.numeric(str_replace_all(as.character(yfdata[, "N_pj"]), "1", "6")),
      Pdf = as.numeric(str_replace_all(as.character(yfdata[, "P_pj"]), "1", "6")),
      Kdf = as.numeric(str_replace_all(as.character(yfdata[, "K_pj"]), "1", "6"))
    )

    yfdata <- transform(yfdata,
      Ndf = as.numeric(str_replace_all(as.character(yfdata[, "Ndf"]), "5", "1")),
      Pdf = as.numeric(str_replace_all(as.character(yfdata[, "Pdf"]), "5", "1")),
      Kdf = as.numeric(str_replace_all(as.character(yfdata[, "Kdf"]), "5", "1"))
    )
    yfdata <- transform(yfdata,
      Ndf = as.numeric(str_replace_all(as.character(yfdata[, "Ndf"]), "4", "2")),
      Pdf = as.numeric(str_replace_all(as.character(yfdata[, "Pdf"]), "4", "2")),
      Kdf = as.numeric(str_replace_all(as.character(yfdata[, "Kdf"]), "4", "2"))
    )
    yfdata <- transform(yfdata,
      Ndf = as.numeric(str_replace_all(as.character(yfdata[, "Ndf"]), "2", "4")),
      Pdf = as.numeric(str_replace_all(as.character(yfdata[, "Pdf"]), "2", "4")),
      Kdf = as.numeric(str_replace_all(as.character(yfdata[, "Kdf"]), "2", "4"))
    )
    yfdata <- transform(yfdata,
      Ndf = as.numeric(str_replace_all(as.character(yfdata[, "Ndf"]), "6", "5")),
      Pdf = as.numeric(str_replace_all(as.character(yfdata[, "Pdf"]), "6", "5")),
      Kdf = as.numeric(str_replace_all(as.character(yfdata[, "Kdf"]), "6", "5"))
    )

    ### 养分综合得分###
    yfdata <- transform(yfdata, yfdf = Ndf * 0.4 + Pdf * 0.4 + Kdf * 0.2)
    ## 养分评价###
    yfdata$yf_pj <- NA
    yfdata[which(yfdata[, "yfdf"] >= 4.5), "yf_pj"] <- 1
    yfdata[which(yfdata[, "yfdf"] >= 3.5 & yfdata[, "yfdf"] < 4.5), "yf_pj"] <- 2
    yfdata[which(yfdata[, "yfdf"] >= 2.5 & yfdata[, "yfdf"] < 3.5), "yf_pj"] <- 3
    yfdata[which(yfdata[, "yfdf"] >= 1.5 & yfdata[, "yfdf"] < 2.5), "yf_pj"] <- 4
    yfdata[which(yfdata[, "yfdf"] < 1.5), "yf_pj"] <- 5
  }


  len1 <- length(names(yffc))

  len2 <- length(name_ele) # 需要扣除掉与yffc前面重复的pred数据列，因此下面起始位置要加上len3的长度
  j <- len2 + 1
  for (i in (len1 + 1):(len1 + len2)) {
    yffc[[i]] <- yfdata[, j] # 空间上数据框赋值用$或[[]]形式单列赋值（所以用了for循环实现多个指标赋值），不能用[x:y]与数据框多个一起赋值
    j <- j + 1
  }
  names(yffc)[(len1 + 1):(len1 + len2)] <- names(yfdata)[(len2 + 1):(2 * len2)]
  return(yffc)
}
