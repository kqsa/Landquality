#' @title insert value
#' @description
#' \code{TBchazhi}insert value to polygon with ordinary Krige
#' @param ele some elements or indicators which will be used to insert value
#' @param data one SpatialPointsDataFrame with CRS
#' @param shp one SpatialPolygonsDataFrame with the same CRS to data
#' @export
#' @return one SpatialPolygonDataFrame
#' @author Kequan-Xu <xukqsa@@163.com>
#' @examples
#' library(sp)
#' library(gstat)
#' library(stringr)
#' data("spatial_data")
#' data("SpatialPolygonsDataFrame")
#' library(sp)
#' coordinates(data) <- c("lon", "lat")
#' proj4string(data) <- CRS("+proj=longlat +datum=WGS84")
#' data <- spTransform(data, CRS("+proj=tmerc +lat_0=0 +lon_0=105 +k=1 +x_0=35500000 +y_0=0 +ellps=GRS80 +units=m +no_defs"))
#' ele <- c("P", "K", "pH", "As", "Hg")
#' m <- TBchazhi(ele, data, tb)
#' summary(m)
TBchazhi <- function(ele, data, shp) {
  if (missing(ele) || missing(data) || missing(shp) || class(data) != "SpatialPointsDataFrame" || class(shp) != "SpatialPolygonsDataFrame") {
    stop("'ele,data or shp is missing' or 'class is wrong'")
  }
  if (proj4string(shp) != proj4string(data)) {
    stop("'proj4string not same'")
  }
  len <- length(names(shp))

  for (i in ele) {
    # 构建半变异函数
    mo <- as.formula(paste("log(", i, ")~1"))
    VM <- variogram(mo, data)
    # 获得拟合值
    vm.fit <- fit.variogram(VM, vgm(400, "Sph", 1000))

    # 块克里金插值
    kk <- krige(mo, data, shp, vm.fit)
    len1 <- len + 1
    shp[[len1]] <- exp(kk[[3]])
    names(shp)[len1] <- str_remove_all(paste(i, "_pred"), " ")
    len <- len + 1
  }
  return(shp)
}
