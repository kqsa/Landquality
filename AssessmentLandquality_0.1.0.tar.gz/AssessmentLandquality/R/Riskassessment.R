#' @title Risk assessment of heavy metal of soil
#' @description
#' \code {Riskassessment} assess the risk of the data coming from the SpatialDataframe-returned from TBchazhi or self-dataframe
#' @param fcdata one dataframe or SpatialDataframe-returned from TBchazhi
#' @param heightele contains heavy metals and pH
#' @param land states of land-used
#' @param explain a logical value.for example \code{TRUE},explain the risk_assessment function's methods of use stoping the function
#' \code{FALSE},running the function
#' @param pd a logical value.for example\code{TRUE},your fcdata's data need to be tranform by exp
#' @export
#' @return a dataframe or SpatialDataframe is the same with the the class of the fcdata
#' @author Kequan-Xu <xukqsa@@163.com>
#' @examples
#' library(sp)
#' library(gstat)
#' library(stringr)
#' data("spatial_data")
#' data("SpatialPolygonsDataFrame")
#' coordinates(data) <- c("lon", "lat")
#' proj4string(data) <- CRS("+proj=longlat +datum=WGS84")
#' data <- spTransform(data, CRS("+proj=tmerc +lat_0=0 +lon_0=105 +k=1 +x_0=35500000 +y_0=0 +ellps=GRS80 +units=m +no_defs"))
#' ele <- c("P", "K", "pH", "As", "Hg")
#' m <- TBchazhi(ele, data, tb)
#' heavy_ele <- c("As", "Hg", "pH")
#' risk_m <- Riskassessment(m, heightele = heavy_ele, land = 'land', explain = \code{FALSE})
#' summary(risk_m)
Riskassessment <- function(fcdata, heightele, land, explain = T, pd = F) {
  PD <- length(grep("_pred", names(fcdata))) # 判断数据框中是否有块克里金函数（KK）插值所有_pred

  KK <- ifelse(PD == 0, FALSE, TRUE)
  print(paste("自动判断是否是块克里金插值后的数据（TRUE为是，FALSE为否）：", KK))
  print(paste("数据类型：", class(fcdata)))
  print(paste("是否有土地利用类型(land)列：", ifelse(sum(names(fcdata) %in% land) == 1, paste("有", land), paste("没有", land))))


  if (explain == T) {
    return(print("(1)导入的数据会自动判断是否由块克里金函数（KK）插值所得，导入数据中有_pred视为块克里金插值所得，
    如果自动判断有误请修改数据列名
    (2)导入数据是否为对数数据，如是对数数据，请将参数pd设为TRUE，不是设置为FLASE;
                 (3)导入数据坐标的名字是否为x和y，如不是需要修改坐标名；
                 (4)参数中land为土地利用类型变量名，且必须有该列属性，pH值列也必须有
                 (5)要运行完程序需要将参数explain设置为FAUSE。"))
  } else if (explain == F) {
    if (KK == TRUE) {
      name_ele <- str_remove_all(paste(heightele, "_pred"), " ")

      name_ele <- names(fcdata)[names(fcdata) %in% name_ele] # 过滤掉数据框中没有的指标
      if (pd == T) {
        expdata <- exp(as.data.frame(fcdata)[name_ele]) # 取掉对数值
        newdata <- cbind(expdata, as.data.frame(fcdata)[land])
      } else if (pd == F) {
        newdata <- cbind(as.data.frame(fcdata)[name_ele], as.data.frame(fcdata)[land])
      }
      # 评价
      for (i in name_ele) {
        if (i == "As_pred") {
          newdata$As_pj <- NA

          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, i] > 100), "As_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] == "水田" & newdata[, i] > 20 & newdata[, i] <= 100), "As_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] != "水田" & newdata[, i] > 25 & newdata[, i] <= 100), "As_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] == "水田" & newdata[, i] <= 20), "As_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] != "水田" & newdata[, i] <= 25), "As_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级

          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, i] > 120), "As_pj"] <- 3 # ph在6.5到7.5间，大于120的，赋值3级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] > 25 & newdata[, i] <= 120), "As_pj"] <- 2 # 水田，大于25，小于等于120，赋值2级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] > 30 & newdata[, i] <= 120), "As_pj"] <- 2 # 非水田，大于30，小于等于120，赋值2级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] <= 25), "As_pj"] <- 1 # 水田，小于25，赋值2级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] <= 30), "As_pj"] <- 1 # 非水田，小于30，小于等于120，赋值2级


          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, i] > 150), "As_pj"] <- 3 # ph在5.5到6.5间，大于150的，赋值3级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] > 30 & newdata[, i] <= 150), "As_pj"] <- 2 # 水田，大于30，小于等于150，赋值2级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] > 40 & newdata[, i] <= 150), "As_pj"] <- 2 # 非水田，大于40，小于等于150，赋值2级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] <= 30), "As_pj"] <- 1 # 水田，小于30，赋值1级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] <= 40), "As_pj"] <- 1 # 非水田，小于40，赋值1级


          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, i] > 200), "As_pj"] <- 3 # ph小于5.5，大于200的，赋值3级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, land] == "水田" & newdata[, i] > 30 & newdata[, i] <= 200), "As_pj"] <- 2 # 水田，大于30，小于等于200，赋值2级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, land] != "水田" & newdata[, i] > 40 & newdata[, i] <= 200), "As_pj"] <- 2 # 非水田，大于40，小于等于200，赋值2级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, land] == "水田" & newdata[, i] <= 30), "As_pj"] <- 1 # 水田，大于30，小于等于200，赋值1级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, land] != "水田" & newdata[, i] <= 40), "As_pj"] <- 1 # 非水田，大于40，小于等于200，赋值1级
        } else if (i == "Cd_pred") {
          newdata$Cd_pj <- NA

          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, i] > 4), "Cd_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] == "水田" & newdata[, i] > 0.8 & newdata[, i] <= 4), "Cd_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] != "水田" & newdata[, i] > 0.6 & newdata[, i] <= 4), "Cd_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] == "水田" & newdata[, i] <= 0.8), "Cd_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] != "水田" & newdata[, i] <= 0.6), "Cd_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级


          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, i] > 3), "Cd_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] > 0.6 & newdata[, i] <= 3), "Cd_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] > 0.3 & newdata[, i] <= 3), "Cd_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] <= 0.6), "Cd_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH_pred"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] <= 0.3), "Cd_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级




          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, i] > 2), "Cd_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] > 0.4 & newdata[, i] <= 2), "Cd_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] > 0.3 & newdata[, i] <= 2), "Cd_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] <= 0.4), "Cd_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级



          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, i] > 1.5), "Cd_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, i] > 0.3 & newdata[, i] <= 1.5), "Cd_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, i] <= 0.3), "Cd_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
        } else if (i == "Cr_pred") {
          newdata$Cr_pj <- NA

          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, i] > 1300), "Cr_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] == "水田" & newdata[, i] > 350 & newdata[, i] <= 1300), "Cr_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] != "水田" & newdata[, i] > 250 & newdata[, i] <= 1300), "Cr_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] == "水田" & newdata[, i] <= 350), "Cr_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] != "水田" & newdata[, i] <= 250), "Cr_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级


          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, i] > 1000), "Cr_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] > 300 & newdata[, i] <= 1000), "Cr_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] > 200 & newdata[, i] <= 1000), "Cr_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] <= 300), "Cr_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] <= 200), "Cr_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级




          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, i] > 850), "Cr_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] > 250 & newdata[, i] <= 850), "Cr_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] > 150 & newdata[, i] <= 850), "Cr_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] <= 250), "Cr_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH_pred"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] <= 150), "Cr_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级




          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, i] > 800), "Cr_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, land] == "水田" & newdata[, i] > 250 & newdata[, i] <= 800), "Cr_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, land] != "水田" & newdata[, i] > 150 & newdata[, i] <= 800), "Cr_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
        } else if (i == "Cu_pred") {
          newdata$Cu_pj <- NA

          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, land] == "水田" & newdata[, i] > 200), "Cu_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, land] != "水田" & newdata[, i] > 100), "Cu_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, land] == "水田" & newdata[, i] <= 200), "Cu_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, land] != "水田" & newdata[, i] <= 100), "Cu_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级

          newdata[which(newdata[, "pH_pred"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] > 150), "Cu_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] > 50), "Cu_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] <= 150), "Cu_pj"] <- 1 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] <= 50), "Cu_pj"] <- 1 # 水田，大于20，小于等于100，赋值2级
        } else if (i == "Hg_pred") {
          newdata$Hg_pj <- NA

          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, i] > 6), "Hg_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] == "水田" & newdata[, i] > 1 & newdata[, i] <= 6), "Hg_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] != "水田" & newdata[, i] > 3.4 & newdata[, i] <= 6), "Hg_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] == "水田" & newdata[, i] <= 1), "Hg_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] != "水田" & newdata[, i] <= 3.4), "Hg_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级


          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, i] > 4), "Hg_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] > 0.6 & newdata[, i] <= 4), "Hg_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] > 2.4 & newdata[, i] <= 4), "Hg_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] <= 0.6), "Hg_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] <= 2.4), "Hg_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级




          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, i] > 2.5), "Hg_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] > 0.5 & newdata[, i] <= 2.5), "Hg_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] > 1.8 & newdata[, i] <= 2.5), "Hg_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] <= 0.5), "Hg_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] <= 1.8), "Hg_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级


          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, i] > 2), "Hg_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, land] == "水田" & newdata[, i] > 0.5 & newdata[, i] <= 2), "Hg_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, land] != "水田" & newdata[, i] > 1.3 & newdata[, i] <= 2), "Hg_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, land] != "水田" & newdata[, i] <= 1.3), "Hg_pj"] <- 1
        } else if (i == "Ni_pred") {
          newdata$Ni_pj <- NA

          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, i] > 190), "Ni_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, i] <= 190), "Ni_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级


          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, i] > 100), "Ni_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, i] <= 100), "Ni_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级

          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, i] > 70), "Ni_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, i] <= 70), "Ni_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级

          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, i] > 60), "Ni_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, i] <= 60), "Ni_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
        } else if (i == "Pb_pred") {
          newdata$Pb_pj <- NA

          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, i] > 1000), "Pb_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] == "水田" & newdata[, i] > 240 & newdata[, i] <= 1000), "Pb_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] != "水田" & newdata[, i] > 170 & newdata[, i] <= 1000), "Pb_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] == "水田" & newdata[, i] <= 240), "Pb_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, land] != "水田" & newdata[, i] <= 170), "Pb_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级


          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, i] > 700), "Pb_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] > 140 & newdata[, i] <= 700), "Pb_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] > 120 & newdata[, i] <= 700), "Pb_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] <= 140), "Pb_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] <= 120), "Pb_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级



          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, i] > 500), "Pb_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] > 100 & newdata[, i] <= 500), "Pb_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] > 90 & newdata[, i] <= 500), "Pb_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] <= 100), "Pb_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH_pred"] > 5.5 & newdata[, "pH_pred"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] <= 90), "Pb_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级


          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, i] > 400), "Pb_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, land] == "水田" & newdata[, i] > 80 & newdata[, i] <= 400), "Pb_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, land] != "水田" & newdata[, i] > 70 & newdata[, i] <= 400), "Pb_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, land] == "水田" & newdata[, i] <= 80), "Pb_pj"] <- 1
          newdata[which(newdata[, "pH_pred"] <= 5.5 & newdata[, land] != "水田" & newdata[, i] <= 70), "Pb_pj"] <- 1
        } else if (i == "Zn_pred") {
          newdata$Zn_pj <- NA

          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, i] > 300), "Zn_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 7.5 & newdata[, i] <= 300), "Zn_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级


          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, i] > 250), "Zn_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] > 6.5 & newdata[, "pH_pred"] <= 7.5 & newdata[, i] <= 250), "Zn_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级

          newdata[which(newdata[, "pH_pred"] <= 6.5 & newdata[, i] > 200), "Zn_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH_pred"] <= 6.5 & newdata[, i] <= 200), "Zn_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
        } else if (i == "pH_pred") {
          newdata$pH_pj <- NA
          newdata[which(newdata[, i] >= 8.5), "pH_pj"] <- "Strong Alkalinity "
          newdata[which(newdata[, i] >= 7.5 & newdata[, i] < 8.5), "pH_pj"] <- "Alkalinity"
          newdata[which(newdata[, i] >= 6.5 & newdata[, i] < 7.5), "pH_pj"] <- "Neutral"
          newdata[which(newdata[, i] >= 5.0 & newdata[, i] < 6.5), "pH_pj"] <- "Acid"
          newdata[which(newdata[, i] < 5.0), "pH_pj"] <- "Strong acid"
          newdata$pH_pj <- as.factor(newdata$pH_pj)
        }
      }
    } else if (KK == FALSE) {
      name_ele <- names(fcdata)[names(fcdata) %in% heightele] # 过滤掉数据框中没有的指标
      if (pd == T) {
        expdata <- exp(fcdata[name_ele]) # 取掉对数值
        newdata <- cbind(expdata, fcdata[land])
      } else if (pd == F) {
        newdata <- cbind(fcdata[name_ele], fcdata[land])
      }
      # 评价
      for (i in name_ele) {
        if (i == "As") {
          newdata$As_pj <- NA

          newdata[which(newdata[, "pH"] > 7.5 & newdata[, i] > 100), "As_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] == "水田" & newdata[, i] > 20 & newdata[, i] <= 100), "As_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] != "水田" & newdata[, i] > 25 & newdata[, i] <= 100), "As_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] == "水田" & newdata[, i] <= 20), "As_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] != "水田" & newdata[, i] <= 25), "As_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级

          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, i] > 120), "As_pj"] <- 3 # ph在6.5到7.5间，大于120的，赋值3级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] > 25 & newdata[, i] <= 120), "As_pj"] <- 2 # 水田，大于25，小于等于120，赋值2级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] > 30 & newdata[, i] <= 120), "As_pj"] <- 2 # 非水田，大于30，小于等于120，赋值2级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] <= 25), "As_pj"] <- 1 # 水田，小于25，赋值2级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] <= 30), "As_pj"] <- 1 # 非水田，小于30，小于等于120，赋值2级


          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, i] > 150), "As_pj"] <- 3 # ph在5.5到6.5间，大于150的，赋值3级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] > 30 & newdata[, i] <= 150), "As_pj"] <- 2 # 水田，大于30，小于等于150，赋值2级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] > 40 & newdata[, i] <= 150), "As_pj"] <- 2 # 非水田，大于40，小于等于150，赋值2级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] <= 30), "As_pj"] <- 1 # 水田，小于30，赋值1级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] <= 40), "As_pj"] <- 1 # 非水田，小于40，赋值1级


          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, i] > 200), "As_pj"] <- 3 # ph小于5.5，大于200的，赋值3级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, land] == "水田" & newdata[, i] > 30 & newdata[, i] <= 200), "As_pj"] <- 2 # 水田，大于30，小于等于200，赋值2级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, land] != "水田" & newdata[, i] > 40 & newdata[, i] <= 200), "As_pj"] <- 2 # 非水田，大于40，小于等于200，赋值2级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, land] == "水田" & newdata[, i] <= 30), "As_pj"] <- 1 # 水田，大于30，小于等于200，赋值1级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, land] != "水田" & newdata[, i] <= 40), "As_pj"] <- 1 # 非水田，大于40，小于等于200，赋值1级
        } else if (i == "Cd") {
          newdata$Cd_pj <- NA

          newdata[which(newdata[, "pH"] > 7.5 & newdata[, i] > 4), "Cd_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] == "水田" & newdata[, i] > 0.8 & newdata[, i] <= 4), "Cd_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] != "水田" & newdata[, i] > 0.6 & newdata[, i] <= 4), "Cd_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] == "水田" & newdata[, i] <= 0.8), "Cd_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] != "水田" & newdata[, i] <= 0.6), "Cd_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级


          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, i] > 3), "Cd_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] > 0.6 & newdata[, i] <= 3), "Cd_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] > 0.3 & newdata[, i] <= 3), "Cd_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] <= 0.6), "Cd_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] <= 0.3), "Cd_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级




          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, i] > 2), "Cd_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] > 0.4 & newdata[, i] <= 2), "Cd_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] > 0.3 & newdata[, i] <= 2), "Cd_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] <= 0.4), "Cd_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级



          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, i] > 1.5), "Cd_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, i] > 0.3 & newdata[, i] <= 1.5), "Cd_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, i] <= 0.3), "Cd_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
        } else if (i == "Cr") {
          newdata$Cr_pj <- NA

          newdata[which(newdata[, "pH"] > 7.5 & newdata[, i] > 1300), "Cr_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] == "水田" & newdata[, i] > 350 & newdata[, i] <= 1300), "Cr_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] != "水田" & newdata[, i] > 250 & newdata[, i] <= 1300), "Cr_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] == "水田" & newdata[, i] <= 350), "Cr_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] != "水田" & newdata[, i] <= 250), "Cr_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级


          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, i] > 1000), "Cr_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] > 300 & newdata[, i] <= 1000), "Cr_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] > 200 & newdata[, i] <= 1000), "Cr_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] <= 300), "Cr_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] <= 200), "Cr_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级




          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, i] > 850), "Cr_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] > 250 & newdata[, i] <= 850), "Cr_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] > 150 & newdata[, i] <= 850), "Cr_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] <= 250), "Cr_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] <= 150), "Cr_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级




          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, i] > 800), "Cr_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, land] == "水田" & newdata[, i] > 250 & newdata[, i] <= 800), "Cr_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, land] != "水田" & newdata[, i] > 150 & newdata[, i] <= 800), "Cr_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
        } else if (i == "Cu") {
          newdata$Cu_pj <- NA

          newdata[which(newdata[, "pH"] > 6.5 & newdata[, land] == "水田" & newdata[, i] > 200), "Cu_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, land] != "水田" & newdata[, i] > 100), "Cu_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, land] == "水田" & newdata[, i] <= 200), "Cu_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, land] != "水田" & newdata[, i] <= 100), "Cu_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级

          newdata[which(newdata[, "pH"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] > 150), "Cu_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] > 50), "Cu_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] <= 150), "Cu_pj"] <- 1 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] <= 50), "Cu_pj"] <- 1 # 水田，大于20，小于等于100，赋值2级
        } else if (i == "Hg") {
          newdata$Hg_pj <- NA

          newdata[which(newdata[, "pH"] > 7.5 & newdata[, i] > 6), "Hg_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] == "水田" & newdata[, i] > 1 & newdata[, i] <= 6), "Hg_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] != "水田" & newdata[, i] > 3.4 & newdata[, i] <= 6), "Hg_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] == "水田" & newdata[, i] <= 1), "Hg_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] != "水田" & newdata[, i] <= 3.4), "Hg_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级


          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, i] > 4), "Hg_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] > 0.6 & newdata[, i] <= 4), "Hg_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] > 2.4 & newdata[, i] <= 4), "Hg_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] <= 0.6), "Hg_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] <= 2.4), "Hg_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级




          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, i] > 2.5), "Hg_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] > 0.5 & newdata[, i] <= 2.5), "Hg_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] > 1.8 & newdata[, i] <= 2.5), "Hg_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] <= 0.5), "Hg_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] <= 1.8), "Hg_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级


          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, i] > 2), "Hg_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, land] == "水田" & newdata[, i] > 0.5 & newdata[, i] <= 2), "Hg_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, land] != "水田" & newdata[, i] > 1.3 & newdata[, i] <= 2), "Hg_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, land] != "水田" & newdata[, i] <= 1.3), "Hg_pj"] <- 1
        } else if (i == "Ni") {
          newdata$Ni_pj <- NA

          newdata[which(newdata[, "pH"] > 7.5 & newdata[, i] > 190), "Ni_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, i] <= 190), "Ni_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级


          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, i] > 100), "Ni_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, i] <= 100), "Ni_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级

          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, i] > 70), "Ni_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, i] <= 70), "Ni_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级

          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, i] > 60), "Ni_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, i] <= 60), "Ni_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
        } else if (i == "Pb") {
          newdata$Pb_pj <- NA

          newdata[which(newdata[, "pH"] > 7.5 & newdata[, i] > 1000), "Pb_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] == "水田" & newdata[, i] > 240 & newdata[, i] <= 1000), "Pb_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] != "水田" & newdata[, i] > 170 & newdata[, i] <= 1000), "Pb_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] == "水田" & newdata[, i] <= 240), "Pb_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, land] != "水田" & newdata[, i] <= 170), "Pb_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级


          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, i] > 700), "Pb_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] > 140 & newdata[, i] <= 700), "Pb_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] > 120 & newdata[, i] <= 700), "Pb_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] == "水田" & newdata[, i] <= 140), "Pb_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, land] != "水田" & newdata[, i] <= 120), "Pb_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级



          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, i] > 500), "Pb_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] > 100 & newdata[, i] <= 500), "Pb_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] > 90 & newdata[, i] <= 500), "Pb_pj"] <- 2 # 非水田，大于25，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] == "水田" & newdata[, i] <= 100), "Pb_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级
          newdata[which(newdata[, "pH"] > 5.5 & newdata[, "pH"] <= 6.5 & newdata[, land] != "水田" & newdata[, i] <= 90), "Pb_pj"] <- 1 # 水田，小于20，小于等于100，赋值1级


          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, i] > 400), "Pb_pj"] <- 3 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, land] == "水田" & newdata[, i] > 80 & newdata[, i] <= 400), "Pb_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, land] != "水田" & newdata[, i] > 70 & newdata[, i] <= 400), "Pb_pj"] <- 2 # 水田，大于20，小于等于100，赋值2级
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, land] == "水田" & newdata[, i] <= 80), "Pb_pj"] <- 1
          newdata[which(newdata[, "pH"] <= 5.5 & newdata[, land] != "水田" & newdata[, i] <= 70), "Pb_pj"] <- 1
        } else if (i == "Zn") {
          newdata$Zn_pj <- NA

          newdata[which(newdata[, "pH"] > 7.5 & newdata[, i] > 300), "Zn_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 7.5 & newdata[, i] <= 300), "Zn_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级


          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, i] > 250), "Zn_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] > 6.5 & newdata[, "pH"] <= 7.5 & newdata[, i] <= 250), "Zn_pj"] <- 1 # 非水田，小于25，小于等于100，赋值1级

          newdata[which(newdata[, "pH"] <= 6.5 & newdata[, i] > 200), "Zn_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
          newdata[which(newdata[, "pH"] <= 6.5 & newdata[, i] <= 200), "Zn_pj"] <- 2 # 判断ph>7.5,As大于100的直接判断为3级
        } else if (i == "pH") {
          newdata$pH_pj <- NA
          newdata[which(newdata[, i] >= 8.5), "pH_pj"] <- "Strong Alkalinity "
          newdata[which(newdata[, i] >= 7.5 & newdata[, i] < 8.5), "pH_pj"] <- "Alkalinity"
          newdata[which(newdata[, i] >= 6.5 & newdata[, i] < 7.5), "pH_pj"] <- "Neutral"
          newdata[which(newdata[, i] >= 5.0 & newdata[, i] < 6.5), "pH_pj"] <- "Acid"
          newdata[which(newdata[, i] < 5.0), "pH_pj"] <- "Strong acid"
          newdata$pH_pj <- as.factor(newdata$pH_pj)
        }
      }
    }
    ### 环境综合评价####
    pjnames <- str_remove(paste(heightele, "_pj"), " ")
    pjnames <- names(newdata)[names(newdata) %in% pjnames] # 过滤掉数据框中没有的指标
    pjnames <- pjnames[-which(pjnames == "pH_pj")] # pH不参与重金属综合评价
    newdata1 <- newdata[, pjnames]
    newdata1$hjzh <- NA
    for (i in 1:nrow(newdata1)) {
      if (max(newdata1[i, ], na.rm = T) == 3) {
        newdata1[i, "hjzh"] <- 3
      }
      else if (max(newdata1[i, ], na.rm = T) == 2) {
        newdata1[i, "hjzh"] <- 2
      }
      else if (max(newdata1[i, ], na.rm = T) == 1) {
        newdata1[i, "hjzh"] <- 1
      }
    }
    len1 <- length(names(fcdata))
    len2 <- length(names(newdata1))
    j <- 1
    for (i in (len1 + 1):(len1 + len2)) {
      fcdata[[i]] <- newdata1[, j] # 空间上数据框赋值用$或[[]]形式单列赋值（所以用了for循环实现多个指标赋值），不能用[x:y]与数据框多个一起赋值
      j <- j + 1
    }


    names(fcdata)[(len1 + 1):(len1 + len2)] <- names(newdata1)
    fcdata$pH_pj <- newdata$pH_pj


    return(fcdata)
  }
}
