#' @title landuse
#' @description a spatialpolygonsDataFrame of landuse which contains CRS '+proj=tmerc +lat_0=0 +lon_0=105 +k=1 +x_0=35500000 +y_0=0 +ellps=GRS80 +units=m +no_defs'
#' @docType data
#' @name SpatialPolygonsDataFrame
#' @format a shp contains DataFrame and Polygons
#' \describe{
#'   \item{x}{coordinates's x}
#'   \item{y}{coordinates's y}#'
#'   \item{ID}{ID of a land}
#'   \item{land}{the land use}

#'   }
#'
#' @source the data coming from sichuan geological survey,in China
#' @author Kequan-Xu <xukqsa@@163.com>
NULL
