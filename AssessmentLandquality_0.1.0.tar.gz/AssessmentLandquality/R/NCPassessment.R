#' @title NCP assessment of heavy metal of foods,such as rice and corn
#' @description
#' \code {NCPassessment} assess the risk of the heaval metals of foods,it's data coming from the SpatialDataframe-returned from TBchazhi or self-dataframe
#' @param data one dataframe or SpatialDataframe-returned from TBchazhi
#' @param ele contains heavy metals ,such as Cd,Pb,Hg,As,Cr,Se

#' @param explain a logical value.for example \code{TRUE},explain the risk_assessment function's methods of use stoping the function
#' \code{FALSE},running the function
#' @export
#' @return a dataframe or SpatialDataframe is the same with the the class of the fcdata
#' @author Kequan-Xu <xukqsa@@163.com>
#' @examples
#'



NCPassessment<-function(data,ele,explain=TRUE){

  if(explain==T){
    return( print("(1)该函数目前用于水稻或玉米粒的《重金属食品安全限量污染》评价
    (2)导入数据是否为对数数据，如是对数数据，请将数据转换为普通数据后导入
    (3)评价结果为逻辑值：TRUE为超标，FALSE为未超标;Se元素'Se-exceed'为超标,'Se-enriched'为富硒,'Normal'为低硒
    (4)所有改好确定后，将explain设置为FAUSE
              "))

  }



  name_ele<-names(data)[names(data)%in%ele]#过滤掉数据框中没有的指标

  newdata<-as.data.frame(data)[,name_ele]

  for(i in name_ele){
    if(i=="Cd"){
      newdata$Cd_pj<-FALSE
      newdata[which(newdata[,i]>0.2),"Cd_pj"]<-TRUE

    }else if(i=="Pb"){
      newdata$Pb_pj<-FALSE
      newdata[which(newdata[,i]>0.2),"Pb_pj"]<-TRUE

    } else if(i=="Hg"){
      newdata$Hg_pj<-FALSE
      newdata[which(newdata[,i]>0.02),"Hg_pj"]<-TRUE

    }    else if(i=="As"){
      newdata$As_pj<-FALSE
      newdata[which(newdata[,i]>0.5),"As_pj"]<-TRUE

    }    else if(i=="Cr"){
      newdata$Cr_pj<-FALSE
      newdata[which(newdata[,i]>1.0),"Cr_pj"]<-TRUE

    } else if(i=="Se"){
      newdata$Se_pj<-'normal'
      newdata[which(newdata[,i]>=0.3),"Se_pj"]<-"Se-exceed"
      newdata[which(newdata[,i]>=0.04&newdata[,i]<0.3),"Se_pj"]<-"Se-enriched"
      newdata$Se_pj<-as.factor(newdata$Se_pj)
    }
  }


  ##农产品综合评价###
  newdata$NCP_ZH_pj<-FALSE
  newdata[which(rowSums(newdata[,-which(names(newdata)=='Se_pj')])>=1),"NCP_ZH_pj"]<-TRUE#重金属任意一个超标，则超标
  newdata[which(newdata[,'Se_pj']=='Se-exceed'),"NCP_ZH_pj"]<-TRUE#Se超标也超标



  len1 <- length(names(data))

  len2 <- length(name_ele)#
  j <- len2+1
  for(i in (len1+1):(len1+len2+1)){#有NCP_ZH_pj所以len1+len2+1
    data[[i]]<-newdata[,j]#空间上数据框赋值用$或[[]]形式单列赋值（所以用了for循环实现多个指标赋值），不能用[x:y]与数据框多个一起赋值
    j <- j+1
  }
  names(data)[(len1+1):(len1+len2+1)] <- names(newdata)[(len2+1):(2*len2+1)]
  return(data)

}
